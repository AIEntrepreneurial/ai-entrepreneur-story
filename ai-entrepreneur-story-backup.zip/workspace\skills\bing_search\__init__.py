"""
Bing Search Skill for OpenClaw
Provides web search functionality using Bing API
"""